-- Optional category images for the customer home category cards.
-- Run once in Supabase SQL Editor before uploading category images.

alter table public.categories
  add column if not exists image_url text;

notify pgrst, 'reload schema';
